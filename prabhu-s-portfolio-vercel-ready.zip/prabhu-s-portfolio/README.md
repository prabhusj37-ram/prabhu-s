# Prabhu S — Digital Marketing Portfolio

A responsive, dark premium portfolio website built with plain HTML, CSS and JavaScript.

## Deploy on Vercel
1. Upload **index.html**, **style.css**, and **script.js** to the root of your GitHub repository.
2. In Vercel, import that repository.
3. Framework preset: **Other** (or leave it as automatically detected).
4. Build command: leave empty.
5. Output directory: leave empty.
6. Deploy.

The important part is that `index.html` is directly in the repository root.

## Customize
- Replace the sample project text in `index.html`.
- Change email/phone/LinkedIn/WhatsApp links in the Contact section.
- Add your profile photo later if you want.
